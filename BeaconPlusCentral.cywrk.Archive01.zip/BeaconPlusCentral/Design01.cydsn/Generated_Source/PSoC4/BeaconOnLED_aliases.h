/*******************************************************************************
* File Name: BeaconOnLED.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BeaconOnLED_ALIASES_H) /* Pins BeaconOnLED_ALIASES_H */
#define CY_PINS_BeaconOnLED_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define BeaconOnLED_0			(BeaconOnLED__0__PC)
#define BeaconOnLED_0_PS		(BeaconOnLED__0__PS)
#define BeaconOnLED_0_PC		(BeaconOnLED__0__PC)
#define BeaconOnLED_0_DR		(BeaconOnLED__0__DR)
#define BeaconOnLED_0_SHIFT	(BeaconOnLED__0__SHIFT)
#define BeaconOnLED_0_INTR	((uint16)((uint16)0x0003u << (BeaconOnLED__0__SHIFT*2u)))

#define BeaconOnLED_INTR_ALL	 ((uint16)(BeaconOnLED_0_INTR))


#endif /* End Pins BeaconOnLED_ALIASES_H */


/* [] END OF FILE */
