/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/



/*

project notes. ensure stack and heap size are modified otherwise printf won't work.
central timeout is set to 5 seconds in guui, adjust as required
advertising mode is set to unconnectable. if you need conencted change this in gui. it will likely require other changes as advertising typically stops once connected
advertising timeout not set in gui as we use te isr/timer to create an event that we use to change the advertising data which requires we stop advertising anyway
*/
#include "project.h"
#include <stdio.h>


CYBLE_CONN_HANDLE_T  connHandle;
CYBLE_GAP_BD_ADDR_T  peerAddr[8];
CYBLE_GAPP_DISC_DATA_T  new_advData;
uint8 BEACONDATA[4] = {0,0,0,0};
uint8 counter=0;



void StackEventHandler(uint32 event,void* eventParam);

CY_ISR_PROTO(TimerBlockIsrHandler);

/* For GCC compiler revise _write() function for printf functionality */
int _write(int file, char *ptr, int len)
{
    int i;
    file = file;
    for (i = 0; i < len; i++)
    {
        UART_UartPutChar(*ptr++);
    }
    return len;
}

int main(void)
{
    BeaconOnLED_Write(0);//on
    CyDelay(1000);//1sec delay
    BeaconOnLED_Write(1);//off
    
    TimerISR_StartEx(TimerBlockIsrHandler);
    Timer_Start();
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    UART_Start();//for debg purposes only

    CyBle_Start(StackEventHandler); /*Start BLE*/
    
    printf("Application started\r\n");

    for(;;)
    {
        /* Place your application code here. */
        
        CyBle_ProcessEvents();
    }
}//end of main

///////////////////////////////////////

CY_ISR(TimerBlockIsrHandler)
{
    counter++;//increment counter
    TimerISR_ClearPending();//clear the isr component interrupt
    Timer_ClearInterrupt(Timer_INTR_MASK_TC);//clear the timer interrupt
    
    BeaconOnLED_Write(~BeaconOnLED_Read());//toggle the red led for display purposes
  
       
    BEACONDATA[0]++; //increment and decrement 2 bytes 
    BEACONDATA[1]--;
    new_advData = *cyBle_discoveryModeInfo.advData;//copy existing advertising data in to new structure
    new_advData.advData[25]=BEACONDATA[0];//load the array in to the last 4 bytes of advertising data
    new_advData.advData[24]=BEACONDATA[1];
    new_advData.advData[23]=BEACONDATA[2];
    new_advData.advData[22]=BEACONDATA[3];
    
   
  
    CyBle_GappStopAdvertisement();//stop advertising otherwise data won't be updated
    /* Assign the new ADV data to stack */
	cyBle_discoveryModeInfo.advData = &new_advData;

    
    CyBle_ProcessEvents();//process events to make sure we get a new stack event
    
}    
/*******************************************************************************
* Function Name: StackEventHandler
********************************************************************************
*
* Summary:
*  This is an event callback function to receive events from the CYBLE Component.
*
* Parameters:
*  uint8 event:       Event from the CYBLE component.
*  void* eventParams: A structure instance for corresponding event type. The
*                     list of event structure is described in the component
*                     datasheet.
*
* Return:
*  None
*
*******************************************************************************/

void StackEventHandler(uint32 event,void* eventParam)
{
    
    /*Declaring local variables*/

    CYBLE_GAPC_ADV_REPORT_T advReport;
    CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReqParam;
    
    
    switch(event)
    {
        /*STACK ON*/
        case CYBLE_EVT_STACK_ON:
     
                 printf("BLE STACK ON:\r\n");
                 printf("\r\n");
                CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
                
            break;
                
            /* SCAN progress result*/
        case CYBLE_EVT_GAPC_SCAN_PROGRESS_RESULT:
            
                /*copy the advertising packet recieved to advReport*/
                advReport=*(CYBLE_GAPC_ADV_REPORT_T *)eventParam;
               
                printf("CYBLE_EVT_GAPC_SCAN_PROGRESS_RESULT:\r\n");
               
               /*==EVENT TYPE===== */
                printf("eventType:");
                
                if( advReport.eventType==CYBLE_GAPC_CONN_UNDIRECTED_ADV)
                {
                    printf("Connectable undirected advertising\r\n");
                }
                else if(advReport.eventType==CYBLE_GAPC_CONN_DIRECTED_ADV)
                {
                    printf("Connectable directed advertising\r\n");
                }
                else if(advReport.eventType==CYBLE_GAPC_SCAN_UNDIRECTED_ADV)
                {
                    printf("Scannable undirected advertising\r\n");
                }
                else if(advReport.eventType==CYBLE_GAPC_NON_CONN_UNDIRECTED_ADV)
                {
                    printf("Non connectable undirected advertising\r\n");
                }
                else if(advReport.eventType==CYBLE_GAPC_SCAN_RSP)
                {
                    printf("SCAN_RSP\r\n");
                }
                
                printf("\r\n");
                
                /*==PEER address type===*/
                printf("    peerAddrType: ");
                
                  if(advReport.peerAddrType==CYBLE_GAP_ADDR_TYPE_PUBLIC)
                {
                    printf("PUBLIC\r\n");
                }
                else if(advReport.peerAddrType==CYBLE_GAP_ADDR_TYPE_RANDOM)
                {
                    printf("RANDOM \r\n");
                }
               
                
                printf("    peerBdAddr: %2.2x%2.2x%2.2x%2.2x%2.2x%2.2x \r\n",
                    advReport.peerBdAddr[5u], advReport.peerBdAddr[4u],
                    advReport.peerBdAddr[3u], advReport.peerBdAddr[2u],
                    advReport.peerBdAddr[1u], advReport.peerBdAddr[0u]);
             
                printf("    last4bytes of advpacket: %2.2x%2.2x%2.2x%2.2x \r\n",
                       advReport.data[advReport.dataLen-4], advReport.data[advReport.dataLen-3],
                       advReport.data[advReport.dataLen-2], advReport.data[advReport.dataLen-1]);
                    
                
                printf("\r\n"); 
            
            break;
           
            /*Adveritising started or stopped*/
         case  CYBLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
                
                //counter is incremented in isr. every 4th time we will start ble central scan

                    if(counter<4)//if less than 4 restart beacon advertising
                    {
                    CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
                    BLUE_Write(1);//led off in advertising mode
                   
                    }
                    else//if it hits 4 start central scan and reset counter
                    {
                        CyBle_GapcStartScan(CYBLE_SCANNING_FAST);//this is set with a time out in the gui config of 5 seconds. change as per requirements
                        counter=0;
                        BLUE_Write(0);//led on in scanning mode
                    }
            
            break;
            
            /*scanning started or stopped*/
         case  CYBLE_EVT_GAPC_SCAN_START_STOP:
                    
                    
                    CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);//if we get a stop event, i.e. it's hit the timeout, make sure we restart advertising
            
            break;
            
        case CYBLE_EVT_GATT_CONNECT_IND:
                
                /*copy the value of connection handle to "connHanlde"  */
                connHandle = *(CYBLE_CONN_HANDLE_T *)eventParam;
        break;
            
        case CYBLE_EVT_GAP_DEVICE_CONNECTED:/*Device connected*/
               
            break;
         
           
         case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:/*Device disconnected*/
  
            break;
           
            /*Write Request  from Client*/
        case CYBLE_EVT_GATTS_WRITE_REQ:
                    
                wrReqParam=(CYBLE_GATTS_WRITE_REQ_PARAM_T*) eventParam;
                                      
                /*write request is for custom characteristic*/
                
//                if(wrReqParam->handleValPair.attrHandle == CYBLE_CUSTOM_SERVICE_CUSTOM_CHARACTERISTIC_CHAR_HANDLE) 
//                {

//                }
//                
//               
//                
//                CyBle_GattsWriteRsp(wrReqParam->connHandle);/* response to write characterisitc from client*/
               
            break;
                
        case CYBLE_EVT_GATTC_WRITE_RSP:     /*Write Response sent for write command*/
                
            break;
         
        default:
            break;
    }
}


/* [] END OF FILE */
